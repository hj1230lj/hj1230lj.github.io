参考学习使用

效果预览

http://ikaros-521.gitee.io/html_login_register/login.html

http://ikaros-521.gitee.io/html_login_register/register.html

http://ikaros-521.gitee.io/html_login_register/login3.html

http://ikaros-521.gitee.io/html_login_register/register3.html


![输入图片说明](https://images.gitee.com/uploads/images/2019/1024/121611_41924ce9_5140590.png "屏幕截图.png")
![输入图片说明](https://images.gitee.com/uploads/images/2019/1024/121625_ec946fb6_5140590.png "屏幕截图.png")

1.3版本 如下：

<img src="https://img-blog.csdnimg.cn/20210518102248570.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L0lrYXJvc181MjE=,size_16,color_FFFFFF,t_70"/>

如果你对后端有兴趣，可以参考 https://blog.csdn.net/Ikaros_521/article/details/102610768 我的这篇文章

在Linux下搭建Boa这个web server，当然也可以使用apache等支持cgi的web server。

如需编译后端程序，在cgi-bin目录下执行 make命令即可。（linux、gcc）

<img src="https://img-blog.csdnimg.cn/20210118110622970.gif"/>
